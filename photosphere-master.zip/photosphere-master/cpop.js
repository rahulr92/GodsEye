sphere = new Photosphere(document.location.search.substr(1));
sphere.loadPhotosphere(document.getElementById("sphere"));
