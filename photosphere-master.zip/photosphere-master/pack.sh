zip extension.zip manifest.json page.js lib/* extern/* cpop.html cpop.js
